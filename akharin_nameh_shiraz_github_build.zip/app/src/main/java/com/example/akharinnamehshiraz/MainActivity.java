package com.example.akharinnamehshiraz;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    ArrayList<Chapter> all = new ArrayList<>(), shown = new ArrayList<>();
    ChapterAdapter adapter;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        load();
        RecyclerView list = findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ChapterAdapter(shown, c -> {
            Intent i = new Intent(this, ReaderActivity.class);
            i.putExtra("number", c.number);
            startActivity(i);
        });
        list.setAdapter(adapter);
        EditText search = findViewById(R.id.search);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ filter(s.toString()); }
            public void afterTextChanged(Editable e){}
        });
    }
    void load() {
        try {
            InputStream is=getAssets().open("chapters.json");
            byte[] bytes=new byte[is.available()]; is.read(bytes); is.close();
            JSONArray arr=new JSONArray(new String(bytes, StandardCharsets.UTF_8));
            for(int i=0;i<arr.length();i++){
                org.json.JSONObject o=arr.getJSONObject(i);
                all.add(new Chapter(o.getInt("number"),o.getString("title"),o.getString("text")));
            }
            shown.addAll(all);
        } catch(Exception e){ Toast.makeText(this,"خطا در بارگذاری کتاب",Toast.LENGTH_LONG).show(); }
    }
    void filter(String q){
        shown.clear();
        for(Chapter c:all) if(q.trim().isEmpty() || ("فصل "+c.number+" "+c.title).contains(q) || c.text.contains(q)) shown.add(c);
        adapter.notifyDataSetChanged();
    }
    static class Chapter {
        int number; String title,text;
        Chapter(int n,String t,String x){number=n;title=t;text=x;}
    }
    interface Click { void go(Chapter c); }
    static class ChapterAdapter extends RecyclerView.Adapter<ChapterHolder>{
        ArrayList<Chapter> data; Click click;
        ChapterAdapter(ArrayList<Chapter>d,Click c){data=d;click=c;}
        public ChapterHolder onCreateViewHolder(ViewGroup p,int v){return new ChapterHolder(LayoutInflater.from(p.getContext()).inflate(R.layout.item_chapter,p,false));}
        public void onBindViewHolder(ChapterHolder h,int pos){Chapter c=data.get(pos);h.tv.setText("فصل "+c.number+" — "+c.title);h.itemView.setOnClickListener(v->click.go(c));}
        public int getItemCount(){return data.size();}
    }
    static class ChapterHolder extends RecyclerView.ViewHolder{
        TextView tv; ChapterHolder(View v){super(v);tv=v.findViewById(R.id.chapterTitle);}
    }
}