package com.example.akharinnamehshiraz;

import android.content.*;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class ReaderActivity extends AppCompatActivity {
    TextView content; float size=19f; boolean dark=false;
    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_reader);
        content=findViewById(R.id.content);
        int n=getIntent().getIntExtra("number",1);
        load(n);
        findViewById(R.id.larger).setOnClickListener(v->{size=Math.min(30,size+2);content.setTextSize(size);});
        findViewById(R.id.smaller).setOnClickListener(v->{size=Math.max(14,size-2);content.setTextSize(size);});
        findViewById(R.id.dark).setOnClickListener(v->{dark=!dark; applyTheme();});
    }
    void load(int n){
        try{
            InputStream is=getAssets().open("chapters.json");
            byte[] bytes=new byte[is.available()];is.read(bytes);is.close();
            JSONArray a=new JSONArray(new String(bytes,StandardCharsets.UTF_8));
            for(int i=0;i<a.length();i++){
                org.json.JSONObject o=a.getJSONObject(i);
                if(o.getInt("number")==n){
                    setTitle("فصل "+n+" — "+o.getString("title"));
                    content.setText("فصل "+n+" — "+o.getString("title")+"\n\n"+o.getString("text"));
                    break;
                }
            }
        }catch(Exception e){content.setText("خطا در باز کردن فصل.");}
    }
    void applyTheme(){
        int bg=dark?Color.rgb(18,18,18):Color.WHITE;
        int fg=dark?Color.WHITE:Color.rgb(30,30,30);
        findViewById(R.id.scroll).setBackgroundColor(bg);
        content.setTextColor(fg);
    }
}