package com.example.akharinnamehshiraz;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaPlayer;

public final class MusicManager {
    private static MediaPlayer player;
    private MusicManager() {}

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences("book", Context.MODE_PRIVATE)
                .getBoolean("music_enabled", true);
    }

    public static void start(Context context) {
        if (!isEnabled(context)) return;
        if (player == null) {
            player = MediaPlayer.create(context.getApplicationContext(), R.raw.bg_music);
            if (player != null) {
                player.setLooping(true);
                player.setVolume(0.24f, 0.24f);
            }
        }
        if (player != null && !player.isPlaying()) player.start();
    }

    public static boolean toggle(Context context) {
        SharedPreferences p = context.getSharedPreferences("book", Context.MODE_PRIVATE);
        boolean enabled = !p.getBoolean("music_enabled", true);
        p.edit().putBoolean("music_enabled", enabled).apply();
        if (enabled) start(context);
        else stop();
        return enabled;
    }

    public static void stop() {
        if (player != null && player.isPlaying()) player.pause();
    }

    public static void release() {
        if (player != null) {
            player.release();
            player = null;
        }
    }
}
