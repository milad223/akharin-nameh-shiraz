package com.example.akharinnamehshiraz;

import android.content.*;
import android.os.Bundle;
import android.text.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    ArrayList<Chapter> all=new ArrayList<>(), shown=new ArrayList<>();
    ChapterAdapter adapter;
    @Override protected void onStart(){ super.onStart(); MusicManager.start(this); }
    @Override protected void onStop(){ MusicManager.stop(); super.onStop(); }
    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        load();
        RecyclerView list=findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter=new ChapterAdapter(shown,c->open(c.number));
        list.setAdapter(adapter);
        EditText search=findViewById(R.id.search);
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){filter(s.toString());}
            public void afterTextChanged(Editable e){}
        });
        LinearLayout cont=findViewById(R.id.continueCard);
        TextView continueText=findViewById(R.id.continueText);
        int last=getSharedPreferences("book",MODE_PRIVATE).getInt("last",0);
        if(last>0){continueText.setText("ادامه از فصل "+last);}
        cont.setOnClickListener(v->open(last>0?last:1));
    }
    void open(int n){
        getSharedPreferences("book",MODE_PRIVATE).edit().putInt("last",n).apply();
        Intent i=new Intent(this,ReaderActivity.class); i.putExtra("number",n); startActivity(i);
    }
    void load(){
        try{
            InputStream is=getAssets().open("chapters.json"); byte[] bytes=new byte[is.available()]; is.read(bytes); is.close();
            JSONArray arr=new JSONArray(new String(bytes, StandardCharsets.UTF_8));
            for(int i=0;i<arr.length();i++){org.json.JSONObject o=arr.getJSONObject(i); all.add(new Chapter(o.getInt("number"),o.getString("title"),o.getString("text")));}
            shown.addAll(all);
        }catch(Exception e){Toast.makeText(this,"خطا در بارگذاری کتاب",Toast.LENGTH_LONG).show();}
    }
    void filter(String q){
        shown.clear(); String x=q.trim();
        for(Chapter c:all) if(x.isEmpty() || ("فصل "+c.number+" "+c.title).contains(x) || c.text.contains(x)) shown.add(c);
        adapter.notifyDataSetChanged();
    }
    static String fa(int n){String[] d={"۰","۱","۲","۳","۴","۵","۶","۷","۸","۹"};String s=""+n,r="";for(char c:s.toCharArray())r+=d[c-'0'];return r;}
    static class Chapter{int number;String title,text;Chapter(int n,String t,String x){number=n;title=t;text=x;}}
    interface Click{void go(Chapter c);}
    static class ChapterAdapter extends RecyclerView.Adapter<ChapterHolder>{
        ArrayList<Chapter> data; Click click; ChapterAdapter(ArrayList<Chapter>d,Click c){data=d;click=c;}
        public ChapterHolder onCreateViewHolder(ViewGroup p,int v){return new ChapterHolder(LayoutInflater.from(p.getContext()).inflate(R.layout.item_chapter,p,false));}
        public void onBindViewHolder(ChapterHolder h,int pos){Chapter c=data.get(pos);h.num.setText(fa(c.number));h.tv.setText(c.title);h.ex.setText(c.text);h.itemView.setOnClickListener(v->click.go(c));}
        public int getItemCount(){return data.size();}
    }
    static class ChapterHolder extends RecyclerView.ViewHolder{TextView num,tv,ex;ChapterHolder(View v){super(v);num=v.findViewById(R.id.chapterNumber);tv=v.findViewById(R.id.chapterTitle);ex=v.findViewById(R.id.chapterExcerpt);}}
}
