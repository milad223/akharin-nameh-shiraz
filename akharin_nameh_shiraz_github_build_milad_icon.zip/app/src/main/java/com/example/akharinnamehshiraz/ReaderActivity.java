package com.example.akharinnamehshiraz;

import android.graphics.Color;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class ReaderActivity extends AppCompatActivity {
    TextView content,title,label,no,bookmark; ScrollView scroll; float size=19f; boolean dark=false; int chapter=1;
    @Override protected void onStart(){ super.onStart(); MusicManager.start(this); }
    @Override protected void onStop(){ MusicManager.stop(); super.onStop(); }
    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_reader);
        content=findViewById(R.id.content); title=findViewById(R.id.contentTitle); label=findViewById(R.id.chapterLabel); no=findViewById(R.id.chapterNo); bookmark=findViewById(R.id.bookmark); scroll=findViewById(R.id.scroll);
        chapter=getIntent().getIntExtra("number",1); load(chapter);
        findViewById(R.id.back).setOnClickListener(v->finish());
        findViewById(R.id.larger).setOnClickListener(v->{size=Math.min(30,size+2);content.setTextSize(size);});
        findViewById(R.id.smaller).setOnClickListener(v->{size=Math.max(14,size-2);content.setTextSize(size);});
        findViewById(R.id.dark).setOnClickListener(v->{dark=!dark;applyTheme();});
        TextView music=findViewById(R.id.music);
        updateMusicButton(music);
        music.setOnClickListener(v->{ MusicManager.toggle(this); updateMusicButton(music); });
        boolean saved=getSharedPreferences("book",MODE_PRIVATE).getBoolean("bookmark_"+chapter,false); setBookmark(saved);
        bookmark.setOnClickListener(v->{boolean x=!getSharedPreferences("book",MODE_PRIVATE).getBoolean("bookmark_"+chapter,false);getSharedPreferences("book",MODE_PRIVATE).edit().putBoolean("bookmark_"+chapter,x).apply();setBookmark(x);});
        getSharedPreferences("book",MODE_PRIVATE).edit().putInt("last",chapter).apply();
    }
    void setBookmark(boolean x){bookmark.setText(x?"♥":"♡");}
    void updateMusicButton(TextView v){v.setText(MusicManager.isEnabled(this)?"♫ موسیقی روشن":"♫ موسیقی خاموش");}
    void load(int n){
        try{InputStream is=getAssets().open("chapters.json");byte[] bytes=new byte[is.available()];is.read(bytes);is.close();JSONArray a=new JSONArray(new String(bytes,StandardCharsets.UTF_8));
            for(int i=0;i<a.length();i++){org.json.JSONObject o=a.getJSONObject(i);if(o.getInt("number")==n){String t=o.getString("title");label.setText("فصل "+n);no.setText("فصل "+n);title.setText(t);content.setText(o.getString("text"));break;}}
        }catch(Exception e){content.setText("خطا در باز کردن فصل.");}
    }
    void applyTheme(){
        int bg=dark?Color.rgb(25,22,21):Color.rgb(255,249,241), fg=dark?Color.rgb(245,238,231):Color.rgb(32,26,23);
        scroll.setBackgroundColor(bg); content.setTextColor(fg); title.setTextColor(fg); no.setTextColor(dark?Color.rgb(210,170,105):Color.rgb(196,154,85)); label.setTextColor(dark?Color.LTGRAY:Color.rgb(109,94,86));
    }
}
